import asyncio
from playwright.async_api import async_playwright
from oracle.login_steps import run_oracle_login_steps
from oracle.ui_mapper.extractor import extract_nav_metadata
from oracle.ui_mapper.db_writer import DBWriter
from utils.logging import debug_log

stop_flag = False

def cancel_crawl():
	global stop_flag
	stop_flag = True

async def crawl_navigation(login_url, username, password, log_callback):
	global stop_flag
	def safe_log(msg): log_callback(f"🔞 {msg}")

	async with async_playwright() as p:
		browser = await p.chromium.launch(headless=False, slow_mo=200)
		page = await browser.new_page()

		safe_log("🌐 Navigating to Oracle login page")
		await run_oracle_login_steps(page, login_url, username, password)

		# 🔍 Check for frames in the page and log them
		frames = page.frames
		for f in frames:
			safe_log(f"🔍 Frame: {f.name} — URL: {f.url}")

		# Use the first real content frame (not blank)
		target_frame = next((f for f in frames if f.url and "blank.html" not in f.url), page)

		# 🌀 Force scroll to trigger lazy-load of nav links
		try:
			await target_frame.evaluate("""() => {
			const panel = document.querySelector('div.sca-scrollable');
			if (panel) {
				panel.dispatchEvent(new Event('mouseenter'));
				panel.dispatchEvent(new Event('mouseover'));
				panel.scrollTop = panel.scrollHeight;
			}
		}""")
			safe_log("🌀 Simulated hover + scroll on nav panel")
		except:
			safe_log("⚠️ Could not scroll nav panel")

		# Wait for nav panel to fully load
		try:
			await target_frame.wait_for_timeout(7000)
		except:
			safe_log("\u26a0\ufe0f Nav links did not appear in time")

		html = await target_frame.content()
		with open("nav_debug.html", "w", encoding="utf-8") as f:
			f.write(html)
		await page.screenshot(path="nav_debug.png", full_page=True)

		safe_log("🔍 Trying selector: div.section a, div.sectionlink a")
		all_links = await target_frame.query_selector_all("a")
		menu_items = []
		for link in all_links:
			try:
				visible = await link.is_visible()
				text = (await link.inner_text()).strip()
				if visible and text and text not in ["Home", "Navigator", "Skip to main content", "Collapse Sales", "Show Less"]:
					menu_items.append(link)
			except:
				continue
		if not menu_items:
			safe_log("📭 No menu items found with primary selector")
			with open("nav_debug_partial.html", "w", encoding="utf-8") as f:
				f.write(await target_frame.content())
			safe_log("📄 Saved fallback HTML to nav_debug_partial.html")
			safe_log("🔁 Trying fallback selector: div[role='link'] a, div[role='menuitem'] a")
			menu_items = await target_frame.query_selector_all("div[role='link'] a, div[role='menuitem'] a")

		headings = await target_frame.query_selector_all("text=Invoices")
		safe_log(f"🧪 Found {len(headings)} elements with text=Invoices")
		safe_log(f"🧪 Total anchor tags: {len(menu_items)}")
		for i, link in enumerate(menu_items[:5]):
			text = await link.inner_text()
			href = await link.get_attribute("href")
			safe_log(f"🔗 Link {i}: text='{text}' | href='{href}'")
		safe_log(f"📋 Found {len(menu_items)} nav items")

		writer = DBWriter("oracle_ui_dump.jsonl")
		current_category = None

		for i, item in enumerate(menu_items):
			label = await item.inner_text()
			if label.startswith("Collapse "):
				current_category = label.replace("Collapse ", "")
				safe_log(f"📁 Category changed: {current_category}")
				continue
			if stop_flag:
				safe_log("🛑 Crawl cancelled by user.")
				break
			try:
				label = await item.inner_text()
				href = await item.get_attribute("href")
				selector = f"a >> nth={i}"
				data = {
					"label": label,
					"selector": selector,
					"url": href or "N/A",
					"category": current_category or "uncategorized",
					"page_id": f"{(current_category or 'uncategorized')}::{label}".lower().replace(" ", "_"),
					"is_external": href.startswith("http") if href else False,
					"has_real_url": href != "#" if href else False,
					"aria_label": await item.get_attribute("aria-label"),
					"title_attr": await item.get_attribute("title"),
					"captured_at": str(asyncio.get_event_loop().time())
				}
				await writer.insert_entry(data)
				safe_log(f"✅ Captured metadata: {label} → {href}")

				# await target_frame.click("button[title='Navigator']")
				# await target_frame.wait_for_timeout(1000)
			except Exception as e:
				safe_log(f"❌ Error on item {i}: {e}")

		safe_log("✅ Crawl complete — closing browser.")
		await browser.close()

def run_with_params(login_url, username, password, log_callback=print):
	global stop_flag
	stop_flag = False

	async def wrapped():
		await crawl_navigation(login_url, username, password, log_callback)

	asyncio.run(wrapped())

if __name__ == "__main__":
	debug_log("⚠️ run_with_params() must be called by web_ui or wrapper.")
