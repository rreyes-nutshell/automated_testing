import os
import psycopg2
from dotenv import load_dotenv
from utils.logging import debug_log

load_dotenv()

def init_db():
    debug_log("Entered")
    conn = psycopg2.connect(os.getenv("DATABASE_URL"))
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS test_sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        script_name TEXT,
        created_by TEXT,
        creation_date TIMESTAMP DEFAULT now(),
        last_updated_by TEXT,
        last_update_date TIMESTAMP DEFAULT now()
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS test_steps (
        id SERIAL PRIMARY KEY,
        session_id UUID REFERENCES test_sessions(id),
        step_number INTEGER,
        instruction TEXT,
        status TEXT,
        result TEXT,
        creation_date TIMESTAMP DEFAULT now(),
        created_by TEXT,
        last_update_date TIMESTAMP DEFAULT now(),
        last_updated_by TEXT
    );
    """)

    conn.commit()
    cur.close()
    conn.close()
    debug_log("Exited")

if __name__ == "__main__":
    init_db()