import os
import inspect

DEBUG_MODE = os.getenv("DEBUG_MODE", "false").lower() == "true"

def debug_log(message):
    if DEBUG_MODE:
        caller = inspect.stack()[1].function
        print(f"🐞 [{caller}] {message}", flush=True)