from flask import Blueprint, render_template, request
from utils.logging import debug_log
from oracle.use_cases import execute_test_steps

oracle_runner_bp = Blueprint("oracle_runner_bp", __name__)

@oracle_runner_bp.route("/", methods=["GET", "POST"])
def index():
    debug_log("Entered")
    result = None
    if request.method == "POST":
        file = request.files.get("test_file")
        if file:
            lines = file.read().decode("utf-8").splitlines()
            result = execute_test_steps(lines)
    debug_log("Exited")
    return render_template("index.html", result=result)