from dotenv import load_dotenv
import os

# Manually load .env from instance folder
dotenv_path = os.path.join(os.path.dirname(__file__), 'instance', '.env')
load_dotenv(dotenv_path)

import os
from flask import Flask, render_template
from routes import register_blueprints
from utils.logging import debug_log

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.secret_key = os.getenv("FLASK_SECRET_KEY", "fallback_secret_key")
    register_blueprints(app)

    print("✅ Registered Flask Endpoints:")
    for rule in app.url_map.iter_rules():
        print(rule.endpoint, rule)

    debug_log("✅ Flask app created")
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)