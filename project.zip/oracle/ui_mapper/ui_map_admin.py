# routes/ui_map_admin.py
from flask import Blueprint, request, render_template, redirect, url_for, flash
from utils.logging import debug_log
from utils.db_utils import get_db_connection
from oracle.ui_mapper.importer import import_jsonl_to_db
import os
import json

ui_map_admin_bp = Blueprint("ui_map_admin", __name__, url_prefix="/ui-map")

@ui_map_admin_bp.route("/")
def index():
	debug_log("Entered")
	conn = get_db_connection()
	cur = conn.cursor()
	cur.execute("""
		SELECT id, page_name, url, version, is_skipped 
		FROM ui_pages 
		ORDER BY page_name
	""")
	pages = cur.fetchall()
	cur.close()
	conn.close()
	debug_log("Exited")
	return render_template("ui_mapper_index.html", pages=pages)

@ui_map_admin_bp.route("/toggle/<int:page_id>", methods=["POST"])
def toggle_skip(page_id):
	debug_log("Entered")
	conn = get_db_connection()
	cur = conn.cursor()
	cur.execute("UPDATE ui_pages SET is_skipped = NOT is_skipped WHERE id = %s", (page_id,))
	conn.commit()
	cur.close()
	conn.close()
	debug_log("Exited")
	return redirect(url_for("ui_map_admin.index"))

@ui_map_admin_bp.route("/import", methods=["POST"])
def import_jsonl():
	debug_log("Entered")
	file = request.files["jsonl_file"]
	if file.filename.endswith(".jsonl"):
		try:
			path = os.path.join("/tmp", file.filename)
			file.save(path)
			import_jsonl_to_db(path, get_db_connection())
			flash("✅ Imported successfully", "success")
		except Exception as e:
			flash(f"❌ Import failed: {str(e)}", "danger")
			debug_log(f"Import failed: {str(e)}")
	else:
		flash("❌ Invalid file type", "danger")
	debug_log("Exited")
	return redirect(url_for("ui_map_admin.index"))

@ui_map_admin_bp.route("/export")
def export_jsonl():
	debug_log("Entered")
	path = "/tmp/exported_ui_map.jsonl"
	from utils.jsonl_exporter import export_db_to_jsonl
	export_db_to_jsonl(path, get_db_connection())
	debug_log("Exited")
	return redirect(url_for("ui_map_admin.download_export"))

@ui_map_admin_bp.route("/export/download")
def download_export():
	return redirect("/static/exported_ui_map.jsonl")  # or use `send_file` for download