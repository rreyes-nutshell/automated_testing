from utils.logging import debug_log

async def extract_nav_metadata(page, selector):
	debug_log("Entered")
	element = await page.query_selector(selector)
	if not element:
		return None

	label = await element.inner_text()
	url = page.url
	href = await element.get_attribute("href")
	title_div = await page.query_selector("div.pageTitle")
	page_title = await title_div.inner_text() if title_div else None

	is_actionable = bool(href and href != "#")
	page_id = href if is_actionable else None

	debug_log(f"Extracted {label}")
	debug_log("Exited")
	return {
		'module_name': label.split(">")[0].strip() if ">" in label else None,
		'selector': selector,
		'url': url,
		'label': label,
		'category': 'Navigation',
		'page_title': page_title,
		'is_actionable': is_actionable,
		'page_id': page_id
	}
