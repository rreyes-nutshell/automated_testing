# ui_mapper/__init__.py
from .views import ui_mapper_bp
