import sys
import os
from dotenv import load_dotenv
from flask import Flask
from routes import register_blueprints
from utils.logging import debug_log

sys.path.append(os.path.abspath(os.path.dirname(__file__)))

load_dotenv()

def create_app():
	app = Flask(__name__, instance_relative_config=True)
	app.secret_key = os.getenv("FLASK_SECRET_KEY", "fallback_secret_key")
	register_blueprints(app)

	print("✅ Registered Flask Endpoints:")
	for rule in app.url_map.iter_rules():
		print(rule.endpoint, rule)
	return app

if __name__ == "__main__":
	app = create_app()
	app.run(debug=True, host="0.0.0.0")
