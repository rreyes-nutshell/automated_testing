import sys
import os

from flask import Flask, render_template, request, redirect, url_for
import threading 

import sys 
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from oracle.ui_mapper.main import run_with_params, cancel_crawl
app = Flask(__name__)
latest_log_lines = []

def append_log(msg):
	latest_log_lines.append(msg)
	if len(latest_log_lines) > 50:
		latest_log_lines.pop(0)

@app.route("/", methods=["GET", "POST"])
def login():
	if request.method == "POST":
		username = request.form.get("username")
		password = request.form.get("password")
		login_url = request.form.get("login_url")

		# Start crawler in background thread
		threading.Thread(
			target=run_with_params,
			args=(login_url, username, password, append_log),
			daemon=True
		).start()

		return redirect(url_for("status"))

	return render_template("login.html")

from flask import Response
from flask import render_template

@app.route("/status")
def status():
	return render_template("status.html", log_lines=latest_log_lines[-50:])




if __name__ == "__main__":
	app.run(debug=True)
