from oracle.services import send_to_ollama, run_playwright_action
from utils.logging import debug_log

def execute_test_steps(steps):
    debug_log("Entered")
    results = []
    for i, step in enumerate(steps):
        prompt = f"Interpret this Oracle test step and return a UI action: {step}"
        action = send_to_ollama(prompt)
        output = run_playwright_action(action)
        results.append((i+1, step, action, output))
    debug_log("Exited")
    return results